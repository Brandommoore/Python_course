def sume(nb1, nb2):
	print(f"The result is {nb1+nb2}")

def reste(nb1, nb2):
	print(f"The result is {nb1-nb2}")

def multiply(nb1, nb2):
	print(f"The result is {nb1*nb2}")

def divide(nb1, nb2):
	print(f"The result is {nb1*nb2}")

def potence(base, exponent):
	print(f"The result is {base**exponent}")

def rounde(nb):
	print(f"The result is {round(nb)}")