from setuptools import setup

setup(
	name="calculus",
	version="0.1",
	description="A couple of mathematical functions",
	author="brandommoore",
	author_email="brmo@localhost.com",
	url="localhost",
	packages=["calculus"]

)